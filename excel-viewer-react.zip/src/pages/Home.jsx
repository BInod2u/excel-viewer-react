import React from "react";

export default function Home() {
  return (
    <div>
      <h1>Welcome</h1>
      <p>This site loads Excel from OneDrive after Microsoft sign in.</p>
    </div>
  );
}
