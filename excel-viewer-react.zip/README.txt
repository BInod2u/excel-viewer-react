Steps:
1. Replace clientId in src/authConfig.js
2. Replace OneDrive Excel path in DataPage.jsx
3. Build with: npm install && npm run build
4. Deploy build folder to GitHub Pages
